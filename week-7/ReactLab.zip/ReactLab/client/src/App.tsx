import { useState } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import OfficeSpaceRentalApp from "@/components/OfficeSpaceRentalApp";
import CricketApp from "@/components/CricketApp";
import EventExamplesApp from "@/components/EventExamplesApp";
import TicketBookingApp from "@/components/TicketBookingApp";
import BloggerApp from "@/components/BloggerApp";

function ReactHandsOnLab() {
  const [activeApp, setActiveApp] = useState("officespace");

  const apps = [
    {
      id: "officespace",
      name: "Office Space Rental",
      description: "JSX • Attributes • Inline CSS",
      icon: "fas fa-building",
      component: OfficeSpaceRentalApp
    },
    {
      id: "cricket",
      name: "Cricket App",
      description: "ES6 • Destructuring • Arrow Functions",
      icon: "fas fa-baseball-ball",
      component: CricketApp
    },
    {
      id: "events",
      name: "Event Examples",
      description: "Synthetic Events • Event Handling",
      icon: "fas fa-mouse-pointer",
      component: EventExamplesApp
    },
    {
      id: "ticketbooking",
      name: "Ticket Booking",
      description: "Conditional Rendering • Login/Logout",
      icon: "fas fa-plane",
      component: TicketBookingApp
    },
    {
      id: "blogger",
      name: "Blogger App",
      description: "Advanced Conditional Rendering",
      icon: "fas fa-blog",
      component: BloggerApp
    }
  ];

  const ActiveComponent = apps.find(app => app.id === activeApp)?.component || OfficeSpaceRentalApp;

  return (
    <div className="bg-gray-50 min-h-screen font-sans">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-custom-primary rounded-lg flex items-center justify-center">
                <i className="fab fa-react text-white text-xl"></i>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">React Hands-On Lab</h1>
                <p className="text-sm text-gray-500">Interactive Learning Platform</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-500">Node.js • NPM • VS Code</span>
              <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                <i className="fas fa-check text-green-600 text-sm"></i>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Navigation */}
          <aside className="lg:w-80 bg-white rounded-xl shadow-sm border">
            <div className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">React Applications</h2>
              <nav className="space-y-2">
                {apps.map((app) => (
                  <button
                    key={app.id}
                    data-testid={`nav-${app.id}`}
                    onClick={() => setActiveApp(app.id)}
                    className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
                      activeApp === app.id
                        ? 'bg-custom-primary text-white font-medium'
                        : 'hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <i className={`${app.icon} ${
                        activeApp === app.id ? 'text-white' : 'text-gray-400'
                      }`}></i>
                      <div>
                        <div className={`font-medium ${
                          activeApp === app.id ? 'text-white' : 'text-gray-900'
                        }`}>
                          {app.name}
                        </div>
                        <div className={`text-sm ${
                          activeApp === app.id ? 'opacity-80' : 'text-gray-500'
                        }`}>
                          {app.description}
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </nav>
              
              <div className="mt-8 p-4 bg-blue-50 rounded-lg">
                <h3 className="font-medium text-blue-900 mb-2">React Concepts Covered</h3>
                <div className="text-sm text-blue-700 space-y-1">
                  <div>• React.createElement() vs JSX</div>
                  <div>• JavaScript expressions in JSX</div>
                  <div>• ES6 features (let, const, arrow functions)</div>
                  <div>• Destructuring & spread operator</div>
                  <div>• Array methods (map, filter)</div>
                  <div>• Synthetic Events & this binding</div>
                </div>
              </div>
            </div>
          </aside>

          {/* Main Content Area */}
          <main className="flex-1">
            <ActiveComponent />
          </main>
        </div>
      </div>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={ReactHandsOnLab} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
